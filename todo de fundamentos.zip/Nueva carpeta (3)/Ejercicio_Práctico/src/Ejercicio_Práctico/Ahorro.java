package Ejercicio_Práctico;

public class Ahorro extends Cuenta {
	private double tasaInteres = 0.03;

	public Ahorro(int numero, double saldo, Persona titular) {
		super(numero, saldo, titular);
	}
	
	@Override
	public String toString() {
		return "Ahorro " + super.toString() + " Tasa " + this.tasaInteres;
	}
	
	@Override
	public void deposito(double monto) {
		double interes = monto * this.tasaInteres;
		this.saldo += monto + interes;
	}
	
	@Override
	public void retiro(double monto) {
		if(this.saldo >= monto) {
			this.saldo -= monto;
		}
	}
}