package Ejercicio_Práctico;


public class Persona {
	private int id;
	private String nombre;
	
	public Persona(int id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Id " + this.id + " Nombre " + this.nombre;
	}
}