package Ejercicio_Práctico;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Persona persona = new Persona(1,"Carlos");
		
		Ahorro cuentaAhorro = new Ahorro(1001,50000,persona);
		System.out.println(cuentaAhorro);
		cuentaAhorro.deposito(10000);
		cuentaAhorro.retiro(20000);
		System.out.println("Saldo Final " + cuentaAhorro);
		
		
		Corriente cuentaCorriente = new Corriente(2001,30000,persona,10000);
		System.out.println(cuentaCorriente);
		cuentaCorriente.deposito(5000);
		cuentaCorriente.retiro(35000);
		System.out.println("Saldo Final " + cuentaCorriente);

	}

}

