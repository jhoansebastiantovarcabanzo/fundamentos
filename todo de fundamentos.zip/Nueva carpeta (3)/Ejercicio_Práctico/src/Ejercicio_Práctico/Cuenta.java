package Ejercicio_Práctico;

public abstract class Cuenta {
	protected int numero;
	protected double saldo;
	protected Persona titular;
	
	public Cuenta(int numero, double saldo, Persona titular) {
		super();
		this.numero = numero;
		this.saldo = saldo;
		this.titular = titular;
	}

	@Override
	public String toString() {
		return "Numero " + this.numero + " Saldo " + this.saldo + " Titular " + this.titular;
	}
	
	public abstract void deposito(double monto);
	
	public abstract void retiro(double monto);
}