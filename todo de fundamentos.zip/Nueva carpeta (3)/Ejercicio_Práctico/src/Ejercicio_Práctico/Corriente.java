package Ejercicio_Práctico;

public class Corriente extends Cuenta {
	private double sobregiroPermitido;

	public Corriente(int numero, double saldo, Persona titular, double sobregiroPermitido) {
		super(numero, saldo, titular);
		this.sobregiroPermitido = sobregiroPermitido;
	}
	
	@Override
	public String toString() {
		return "Corriente " + super.toString() + " Sobregiro " + this.sobregiroPermitido;
	}
	
	@Override
	public void deposito(double monto) {
		this.saldo += monto;
	}
	
	@Override
	public void retiro(double monto) {
		if(this.saldo + this.sobregiroPermitido >= monto) {
			this.saldo -= monto;
		}
	}
}