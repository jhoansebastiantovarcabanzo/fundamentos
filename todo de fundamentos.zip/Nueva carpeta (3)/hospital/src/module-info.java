/**
 * 
 */
/**
 * 
 */
module hospital {
}