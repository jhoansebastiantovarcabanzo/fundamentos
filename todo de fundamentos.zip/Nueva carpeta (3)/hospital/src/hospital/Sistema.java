package hospital;

import java.util.List;

public class Sistema {
	
	private List<Paciente>  listaPaciente;
	
	
	
	

}
